document.addEventListener('DOMContentLoaded', function() {
    // JavaScript pro přidání funkcionalit
});




